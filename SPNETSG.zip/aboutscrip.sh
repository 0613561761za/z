#!/bin/bash
#����ǡѺʤ�Ի���

clear
echo -e "Auto Install SSH OVPN" 
echo -e ""
echo -e "For Debian 7-8"
echo -e "For VPS&Cloud"
echo -e ""
echo -e "Script BY SP-NET:"
echo -e "Line http://line.me/ti/p/Tr8OCQghLc"
echo -e ""
